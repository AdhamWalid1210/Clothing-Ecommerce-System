# Selenium Test Project

This project contains automated test cases for a web application.

## How to Run Tests
1. Install dependencies:
   ```bash
   pip install -r requirements.txt